package com.newgen.omniforms.user;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.excp.CustomExceptionHandler;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.skutil.SKLogger;

import javax.faces.application.*;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import javax.faces.validator.ValidatorException;


public class RLOS_Reject extends RLOSCommon implements FormListener
{

	public void formLoaded(FormEvent pEvent)
	{
		System.out.println("Inside RLOS_Reject RLOS");
		SKLogger.writeLog("RLOS RLOS_Reject", "Inside formLoaded()" + pEvent.getSource().getName());

	}
	public void formPopulated(FormEvent pEvent) {
		FormReference formObject = FormContext.getCurrentInstance().getFormReference();
		try{
			System.out.println("Inside RLOS_Reject RLOS");
			SKLogger.writeLog("RLOS RLOS_Reject", "Inside formPopulated()" + pEvent.getSource());
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			String currDate = format.format(Calendar.getInstance().getTime());
			SKLogger.writeLog("RLOS RLOS_Reject", "currTime:" + currDate);
			// formObject.setNGValue("Intro_Date",currDate);
			formObject.setNGValue("Intro_Date",formObject.getNGValue("Created_Date"));
			formObject.setNGValue("Channel_Name",formObject.getNGValue("initiationChannel"));

			formObject.setNGValue("ApplicationRefNo", formObject.getNGValue("NewApplicationNo"));
			if(formObject.getNGValue("cmplx_Customer_FIrstNAme")==null)
			{
				formObject.setNGValue("cmplx_Customer_FIrstNAme","");
			}

			else if(formObject.getNGValue("cmplx_Customer_MiddleName")==null)
			{
				formObject.setNGValue("cmplx_Customer_MiddleName","");
			}

			else if( formObject.getNGValue("cmplx_Customer_LAstNAme")==null)
			{
				formObject.setNGValue("cmplx_Customer_LAstNAme","");
			}
			else
				formObject.setNGValue("Cust_Name",formObject.getNGValue("cmplx_Customer_FIrstNAme")+formObject.getNGValue("cmplx_Customer_MiddleName")+formObject.getNGValue("cmplx_Customer_LAstNAme"));

		}catch(Exception e)
		{
			SKLogger.writeLog("RLOS RLOS_Reject", "Exception:"+e.getMessage());
		}
	}
	public void eventDispatched(ComponentEvent pEvent) throws ValidatorException
	{
		FormReference formObject = FormContext.getCurrentInstance().getFormReference();
		String popupFlag="N";
		String popUpMsg="";
		String popUpControl="";
		try
		{
			switch (pEvent.getType()) 
			{
			case FRAME_EXPANDED:
						SKLogger.writeLog("RLOS FRAG LOADED eventDispatched()", "EventName:" + pEvent.getType() + "#ControlName#" + pEvent.getSource().getName());					
						new RLOSCommonCode().FrameExpandEvent(pEvent);
						break;

			case FRAGMENT_LOADED:
				new RLOSCommonCode().DisableFragmentsOnLoad(pEvent);
				break;
				
			}

		}
		catch(Exception ex)
		{
			if(ex instanceof ValidatorException)
			{   
				if(popupFlag.equalsIgnoreCase("Y"))
				{

					if(popUpControl.equals(""))
					{
						throw new ValidatorException(new FacesMessage(popUpMsg));
					}else
					{
						throw new ValidatorException(new FacesMessage(popUpMsg,popUpControl));

					}

				}
				else{
					HashMap<String,String> hm=new HashMap<String,String>();
					hm.put("Error","Checked");
					if(!popUpMsg.equals("")) {
						try{ throw new ValidatorException(new CustomExceptionHandler("Details Fetched", popUpMsg,"EventType", hm));}finally{hm.clear();}

					} else {
						try{ throw new ValidatorException(new CustomExceptionHandler("Error Message", "Text1","EventType", hm));}finally{hm.clear();}

					}

				}
			}
			else
			{
				ex.printStackTrace();
				System.out.println("exception in eventdispatched="+ ex);
			}
		}
	}

	public void saveFormCompleted(FormEvent pEvent) {
		SKLogger.writeLog("RLOS RLOS_Reject", "Inside saveFormCompleted()" + pEvent);
		FormContext.getCurrentInstance().getFormReference();


	}


	public void submitFormCompleted(FormEvent pEvent)
			throws ValidatorException {
		SKLogger.writeLog("RLOS RLOS_Reject", "Inside submitFormCompleted()" + pEvent);
		FormReference formObject = FormContext.getCurrentInstance().getFormReference();
		formObject.setNGValue("Decision", formObject.getNGValue("cmplx_DecisionHistory_Decision"));
		SKLogger.writeLog("RLOS Initiation", "Value Of decision is:"+formObject.getNGValue("cmplx_DecisionHistory_Decision"));

		saveIndecisionGrid();
	}

	public void continueExecution(String eventHandler, HashMap<String, String> m_mapParams) {
	}


	public void initialize() {
		SKLogger.writeLog("RLOS RLOS_Reject", "Inside initialize()");
	}

	public void saveFormStarted(FormEvent arg0) throws ValidatorException {
		// TODO Auto-generated method stub

	}
	public void submitFormStarted(FormEvent arg0) throws ValidatorException {
		// TODO Auto-generated method stub

	}
	public String decrypt(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	public String encrypt(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}
