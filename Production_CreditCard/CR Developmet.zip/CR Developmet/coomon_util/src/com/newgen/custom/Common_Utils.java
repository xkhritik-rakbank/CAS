package com.newgen.custom;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.PeriodType;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;

public class Common_Utils implements Serializable{
	//String processName;
	//String fileName;
	Logger mLogger;
	
	public Common_Utils(Logger mLogger)
	{
		this.mLogger=mLogger;
	}

	public void getAge(String dateBirth,String controlName){
		try{
			FormReference formObject = FormContext.getCurrentInstance().getFormReference();
			mLogger.info("RLOS_Common123"+ "Inside getAge(): "); 
			/*	Calendar dob = Calendar.getInstance();
				Calendar today = Calendar.getInstance();
				String[] parts;*/
				 DateTimeFormatter dtf ;
				if (dateBirth.contains("/")){
					dtf = DateTimeFormat.forPattern("dd/MM/yyyy");
				}
				
				else{
					dtf = DateTimeFormat.forPattern("yyyy/MM/dd");
				}
					
				LocalDate today = LocalDate.now();
				 // String date = "01/01/2010";
				   LocalDate oldDate= dtf.parseLocalDate(dateBirth);
				   //LocalDate localDate_4= dtf.parseLocalDate("01/12/2018");
				        //LocalDate localDate = LocalDate.parse(date);
				Period period = new Period(oldDate, today, PeriodType.yearMonthDay());

				int diff_days=period.getDays();
				int diff_months=period.getMonths();
				int diff_years=period.getYears();
				if(diff_days>0){
					diff_months++;
					if(diff_months==12){
						diff_months=00;
						diff_years++;
					}
				}
				String final_months=diff_months+"";
				if(final_months.length()<2){
					final_months="0"+final_months;
					}
					mLogger.info("Age is====== "+diff_years+"."+final_months);
				formObject.setNGValue(controlName,(diff_years+"."+final_months).toString(),false); 
		}

		catch(Exception e){
			mLogger.info("Exception:"+e.getMessage());
			printException(e);
		}
}
	
	//overloaded function added on 26/2/18 by akshay
	public String  getAge(String dateBirth){
		try{
			mLogger.info("RLOS_Common123"+ "Inside getAge(): "); 
		/*	Calendar dob = Calendar.getInstance();
			Calendar today = Calendar.getInstance();
			String[] parts;*/
			 DateTimeFormatter dtf ;
			if (dateBirth.contains("/")){
				dtf = DateTimeFormat.forPattern("dd/MM/yyyy");
			}
			
			else{
				dtf = DateTimeFormat.forPattern("yyyy/MM/dd");
			}
				
			LocalDate today = LocalDate.now();
			 // String date = "01/01/2010";
			   LocalDate oldDate= dtf.parseLocalDate(dateBirth);
			   //LocalDate localDate_4= dtf.parseLocalDate("01/12/2018");
			        //LocalDate localDate = LocalDate.parse(date);
			Period period = new Period(oldDate, today, PeriodType.yearMonthDay());

			int diff_days=period.getDays();
			int diff_months=period.getMonths();
			int diff_years=period.getYears();
			if(diff_days>0){
				diff_months++;
				if(diff_months==12){
					diff_months=00;
					diff_years++;
				}
			}
			String final_months=diff_months+"";
			if(final_months.length()<2){
				final_months="0"+final_months;
				}
				mLogger.info("Age is====== "+diff_years+"."+final_months);
				return (diff_years+"."+final_months).toString();
				
	}catch(Exception e){
		mLogger.info("Exception:"+e.getMessage());
		printException(e);
		return "";
	}
		 
	}
	
	public  String getAge_Dectech(String DOB)
	{
		LocalDate today = LocalDate.now();
		//LocalDate birthday = LocalDate.of(1960, Month.JANUARY, 1);
		 // String date = "01/01/2010";
		   DateTimeFormatter dtf = DateTimeFormat.forPattern("dd/MM/yyyy");
		   LocalDate oldDate= dtf.parseLocalDate(DOB);
		   //LocalDate localDate_4= dtf.parseLocalDate("01/12/2018");
				//default, ISO_LOCAL_DATE
		        //LocalDate localDate = LocalDate.parse(date);
		//Period p = Period.between(localDate, today);
		Period period = new Period(oldDate, today, PeriodType.yearMonthDay());
		//Now access the values as below
		String diff_days=period.getDays()+"";
		String diff_months=period.getMonths()+"";
		String diff_years=period.getYears()+"";

		if(diff_days.length()==1){
			diff_days="0"+diff_days;	
		}
		if(diff_months.length()==1){
			diff_months="0"+diff_months;	
		}
		if(diff_years.length()==1){
			diff_years="0"+diff_years;	
		}
		System.out.println(diff_years+"."+diff_months+"."+diff_days);
		
		return diff_years+"."+diff_months+"."+diff_days;
		
	}

	
	
	public  String Convert_dateFormat(String date,String Old_Format,String new_Format)
	{
		mLogger.info("RLOS Common "+ "Inside Convert_dateFormat()"+date);
		String new_date="";
		if(!"".equals(Old_Format) && (date==null || date.equals("")))
		{
			return new_date;
		}
		
		try{
			SimpleDateFormat sdf_old=new SimpleDateFormat(Old_Format);
			SimpleDateFormat sdf_new=new SimpleDateFormat(new_Format);

			if("".equals(Old_Format) || "".equals(date)){
				new_date=sdf_new.format(new Date());
			}
			else{
			new_date=sdf_new.format(sdf_old.parse(date));
			}
		}
		catch(Exception e)
		{
			mLogger.info("RLOS Common "+ "Exception occurred in parsing date:"+e.getMessage());
			printException(e);
		}
		return new_date;
	}
	
	 public   void printException(Exception e){
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String exception = sw.toString();
			mLogger.info("Inside exception :"+"\n"+e.getMessage()+" : \n"+exception);	
			
		}
	 
	 public  void createLogFile(String processName,String fileName)
		{		 
		
		 try
			{
			//Commented by Deepak not to create logs 18 March 2019
				Date date = new Date();
				DateFormat logDateFormat = new SimpleDateFormat("dd-MM-yyyy");
				String logFilePath=System.getProperty("user.dir") + File.separatorChar+"RLOSLogs"+File.separatorChar+logDateFormat.format(date);	
				String logFileName=fileName+".log";			
				String dynamicLog = logFilePath+File.separatorChar+logFileName;
				 Properties p = new Properties();  
				String log4JPropertyFile = new StringBuilder().append(System.getProperty("user.dir"))
						.append(System.getProperty("file.separator")).append("CustomConfig")
						.append(System.getProperty("file.separator")).append("log4j_rakbank.properties").toString();
				//System.out.println("1saurabh$$");
				p.load(new FileInputStream(log4JPropertyFile));			
				
				File d = new File(logFilePath);
				d.mkdirs();			
				 
				File fl = new File(dynamicLog);
				
					if(fl.createNewFile()){
						mLogger.info("Log file created successfully");
					}
					else{
						mLogger.info("Error occurred while creating the log file");
					}
					
				p.put( "log4j.category.mLogger_"+processName.toLowerCase(), p.getProperty("log4j.category.mLogger").replaceAll("mLogger", "mLogger_"+processName.toLowerCase()));
				p.put( "log4j.additivity.mLogger_"+processName.toLowerCase(), p.getProperty("log4j.additivity.mLogger"));			
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase(), p.getProperty("log4j.appender.mLogger"));
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase()+".File", dynamicLog);
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase()+".MaxFileSize", p.getProperty("log4j.appender.mLogger.MaxFileSize"));
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase()+".MaxFileSize", p.getProperty("log4j.appender.mLogger.MaxFileSize"));
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase()+".MaxBackupIndex", p.getProperty("log4j.appender.mLogger.MaxBackupIndex"));
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase()+".layout", p.getProperty("log4j.appender.mLogger.layout"));
				p.put( "log4j.appender.mLogger_"+processName.toLowerCase()+".layout.ConversionPattern", p.getProperty("log4j.appender.mLogger.layout.ConversionPattern"));
				
				PropertyConfigurator.configure( p );	
				
				//Commented by Deepak not to create logs 18 March 2019
				
				// CODE for deletion of log files :: To be configured later according to requirement
				
				/*
				int logsBackupDays=20;
				File logFileFolder = new File(System.getProperty("user.dir") + File.separatorChar+"RLOSLogs");			
				checkDirectory(logFileFolder);				
				File[] list = logFileFolder.listFiles();
				Calendar lCal = Calendar.getInstance(); // initializes with today
				lCal.add(Calendar.DATE, (-1)*logsBackupDays); // Captures a date which is 10 days before today
							
				for(int i=0;i<list.length;i++)
				{				
					File backupFile=new File(logFileFolder+File.separator+list[i].getName());
					Date fileModDate=new Date(backupFile.lastModified());
					if(fileModDate.before(lCal.getTime()))
					{								
						FileUtils.forceDelete(backupFile);
					}		
				}
				*/
				
			}
			catch(Exception e)
			{
				printException(e);			  
			}
			
		}
	 
	public String murabhaTags(String winame){
		try{
			String final_xml = null;
			
			return final_xml;
		}catch(Exception ex){
			printException(ex);
			return null;
		}
		
	}
	
	public void checkDirectory(File dir) 
	{
        if(dir!=null && !dir.isDirectory())
        {
        	mLogger.debug(dir+" Directory Not Found. Trying to create");
        	if(dir.mkdirs())
        	{
        		mLogger.debug(dir+" Directory .Created Successfully");
        	}
        }		
	}
	
	 public String murabhaTags(String winame, List<List<String>> temp2){
			try{
				
				String final_xml = null;
				Map<String,String> temp = new TreeMap<String,String>();
				
				final ResourceBundle properties = PropertyResourceBundle.getBundle("com.newgen.custom.config");
				String columns ="";
				String query="";
				Enumeration enuKeys = properties.getKeys();
				while (enuKeys.hasMoreElements()) {
					String key = (String) enuKeys.nextElement();
					if(key.indexOf("Murabha_")==0){
						String value = properties.getString(key);
						key=key.substring(key.indexOf("_")+1, key.length());
						temp.put(key,value);
					}
				}
				
				for(String it: temp.keySet()) {
					String value = temp.get(it);
					if("".equals(value)){
						columns+="'',";
					}
					else{
						columns+=value+",";
					}
				}
				
				if(!"".equals(columns)){
					if(columns.endsWith(",")){
						columns=columns.substring(0, columns.length()-1);
					}
					query="select "+columns+" from ng_rlos_Murabha_Warranty where Murhabha_WIName='"+winame+"'";
				}
				System.out.println(query);
				
				List<List<String>> result=temp2;//formObject.getDataFromDataSource(query);
				if(result!=null && result.size()>0 && result.get(0)!=null){
					int i=0;
					for(String key : temp.keySet()){
						temp.put(key, result.get(0).get(i));
						i++;
						System.out.println(key + ":" + temp.get(key));
						//mLogger.info("key : "+ key+ " and  value: "+temp.get(key));
					}
				}
				
				
				
				return productInfoTags("Murabha", temp.get("ProductId"), temp);
			}catch(Exception ex){
				//printException(ex);
				ex.printStackTrace();
				return null;
			}
			
		}
	 
	 public String productInfoTags(String prodname,String prodId,Map<String,String> refTags) {
		 try {
		 String ret_xml = "<ProductInfo>";
		 ret_xml+="<ProductName>"+prodname+"</ProductName>";
		 ret_xml+="<ProductId>"+prodId+"</ProductId>";
		 for(String key:refTags.keySet()) {
			 if(key!=null && refTags.get(key)!=null && !"".equals(refTags.get(key))) {
				 ret_xml+="<ProductRefInfo><RefType>"+key+"</RefType><RefValue>"+refTags.get(key)+"</RefValue></ProductRefInfo>"; 
			 }
		 }
		 ret_xml+="</ProductInfo>";
		 
		 return ret_xml;
		 }catch(Exception ex) {
			 ex.printStackTrace();
			 return null;
		 }
	 }
	 
	 //changes done by Saurabh for Murhaba tags CR
	 public String murabhaTags(String winame,String scheme_id,String cardProd){
			try{
				FormReference formObject = FormContext.getCurrentInstance().getFormReference();
				String final_xml = "";
				String prodId="";
				String sTableName = "";
				String sWiCol = "";
				Map<String,String> temp = new TreeMap<String,String>();
				final ResourceBundle properties = PropertyResourceBundle.getBundle("com.newgen.custom.config");
				String columns ="";
				String query="";
				Enumeration enuKeys = properties.getKeys();
				while (enuKeys.hasMoreElements()) {
					String key = (String) enuKeys.nextElement();
					if(key.indexOf(scheme_id)==0){
						String value = properties.getString(key);
						if("TableName".equals(key.substring(key.indexOf("_")+1, key.length()))){
							sTableName = value;
						}
						else if("WiCol".equals(key.substring(key.indexOf("_")+1, key.length()))){
							sWiCol = value;
						}
						else{
						key=key.substring(key.indexOf("_")+1, key.length());
						temp.put(key,value);
						}
					}
				}
				
				for(String it: temp.keySet()) {
					String value = temp.get(it);
					if("".equals(value)){
						columns+="'',";
					}
					else{
						columns+=value+",";
					}
				}
				
				if(!"".equals(columns)){
					if(columns.endsWith(",")){
						columns=columns.substring(0, columns.length()-1);
					}
					query="select top 1 "+columns+" from "+sTableName+" where "+sWiCol+"='"+winame+"' and Card_Product='"+cardProd+"'";
				}
				mLogger.info("query for murabha tags :"+ query);
				List<List<String>> result=formObject.getDataFromDataSource(query);
				if(result!=null && result.size()>0 && result.get(0)!=null){
					for(List<String> row : result) {
						int i=0;
						for(String key : temp.keySet()){
							if(key.equals("ProductId")) {
								prodId = row.get(i);
							}
							else{
							temp.put(key, row.get(i));
							}
							i++;
							
							mLogger.info("key : "+ key+ " and  value: "+temp.get(key));
						}
						temp.remove("ProductId");
						final_xml += productInfoTags(scheme_id, prodId, temp);
					}
					mLogger.info("finalxml for murabha tags :"+ final_xml);
				}
				return final_xml;
			}catch(Exception ex){
				mLogger.info("exception in murabha function :"+ ex.getMessage());
				printException(ex);
				ex.printStackTrace();
				return "";
			}
			
		}
}
